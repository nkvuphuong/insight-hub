# Schema: gea__silver

**Layer:** Silver (fact tables, dimensions, enriched từ geadb__bronze)
**Last updated:** 2026-03-13
**Tables:** 33 (bao gồm views và internal materialized views)
**Main tables:** 29 (trừ 4 internal `mv__*` tables)

---

## Quick Reference — Tables theo nhóm

### Dictionaries (in-memory lookup, không cần JOIN)
- `dict_attribute` — attribute ID → quantity
- `dict_exproduct` — external product ID → name, SKU
- `dict_order_status` — ord_status_custom → business status
- `dict_payment_status` — payment_status → business status
- `dict_product_type` — ordi_type → type_name

### Dimensions
- `dim_business_day` — calendar of business days (~7.7K rows)
- `dim_facility` — fulfill facilities (3 rows: US, VN, etc.)
- `dim_order_identity` — order ID mapping: OMS ID ↔ vendor_ref ↔ seller/store (~14.6M rows)
- `dim_order_status_mapping` — order status code → business status (16 rows)
- `dim_payment_status_mapping` — payment status code → business status (4 rows)
- `dim_seller` — seller dimension (0 rows — empty)
- `dim_time` — date dimension (~11.3K rows) ⭐
- `dim_time_bd` — date dimension with business day sequence (~11.3K rows)

### Fact Tables
- `fact_order` — enriched orders (0 rows — empty, replaced by fact_order_v1)
- `fact_order_event` — order events / CDC-style events (0 rows — empty)
- `fact_order_fulfillment_performance` — fulfillment SLA per order (~1.7M rows) ⭐
- `fact_order_fulfillment_performance_by_product` — fulfillment SLA per order+product (~1.5M rows)
- `fact_order_line` — order line items (0 rows — empty, replaced by v__fact_order_line)
- `fact_order_v1` — active orders fact table (~14.5M rows) ⭐
- `fact_order_v3` — V3 orders fact table (~80.5K rows)
- `fact_production_order_sla_tracker` — live SLA tracker per order item (~1.3K rows)
- `fact_production_order_sla_tracker_daily_snapshot` — daily snapshots of SLA (~228.6K rows)

### Views (không cần FINAL)
- `v__fact_order_line` — view trên fact_order_line
- `v__g5000_dtg_campaign_2025` — G5000 DTG campaign 2025 data
- `v__order_production_sla_backlog_daily_clearance` — daily backlog clearance
- `v__usps_fulfilled_to_delivered_days` — USPS fulfilled → delivered days
- `v__usps_fulfilled_to_first_scan_days` — USPS fulfilled → first scan days
- `v__usps_paided_to_first_scan_days` — USPS paid → first scan days
- `v__usps_shipping_day` — USPS shipping days (business days)
- `v__usps_tracking_first_scan` — first scan events
- `v_production_backlog_clearance_intraday` — intraday backlog clearance

### Internal (không query trực tiếp)
- `mv__fact_order_fulfillment_performance` — MV populating fact_order_fulfillment_performance
- `mv__fact_order_fulfillment_performance_by_product` — MV populating by_product variant
- `mv__fact_production_order_sla_tracker` — MV populating sla_tracker
- `mv__g5000_dtg_campaign_2025` — MV for DTG campaign

---

## Tables (chi tiết)

> 🔄 = SharedReplacingMergeTree (cần FINAL)
> 🔵 = SharedMergeTree / Dictionary / View (không cần FINAL)

---

### `dict_attribute` 🔵
> Engine: Dictionary | Rows: -
> In-memory lookup: attribute ID → quantity

| Column | Type | Ghi chú |
|---|---|---|
| attr_id | UInt64 | PK |
| attr_quantity | Float64 | |

---

### `dict_exproduct` 🔵
> Engine: Dictionary | Rows: -
> In-memory lookup: external product info

| Column | Type | Ghi chú |
|---|---|---|
| exp_id | UInt64 | PK |
| exp_name | String | tên sản phẩm |
| exp_sku | String | SKU |

---

### `dict_order_status` 🔵
> Engine: Dictionary | Rows: -
> In-memory lookup: ord_status_custom → business status

| Column | Type | Ghi chú |
|---|---|---|
| ord_status_custom | UInt64 | PK (lookup key) |
| business_status_code | Int8 | business status code |
| business_status_name | String | human-readable status ⭐ |
| status_group | String | status group (e.g. 'fulfilled', 'cancelled') ⭐ |
| ord_status | Int8 | raw ord_status |
| is_terminal | UInt8 | 1 = terminal state |
| is_success | UInt8 | 1 = successful terminal |
| is_failure | UInt8 | 1 = failed terminal |

---

### `dict_payment_status` 🔵
> Engine: Dictionary | Rows: -
> In-memory lookup: payment_status → business status

| Column | Type | Ghi chú |
|---|---|---|
| payment_status | UInt64 | PK (lookup key) |
| business_status_name | String | human-readable name |
| description | String | |
| is_terminal | UInt8 | |
| is_success | UInt8 | |
| is_failure | UInt8 | |

---

### `dict_product_type` 🔵
> Engine: Dictionary | Rows: -
> In-memory lookup: ordi_type → type_name

| Column | Type | Ghi chú |
|---|---|---|
| ordi_type | UInt64 | PK (= nh_order_item.ordi_type) |
| type_name | String | product type name ⭐ |

---

### `dim_business_day` 🔵
> Engine: SharedMergeTree | Rows: ~7.7K
> Business day calendar

| Column | Type | Ghi chú |
|---|---|---|
| full_date | Date | PK / ORDER BY |
| biz_day_idx | UInt32 | business day index (sequential) |

---

### `dim_facility` 🔵
> Engine: SharedMergeTree | Rows: 3
> Fulfill facility lookup (US, VN, etc.)

| Column | Type | Ghi chú |
|---|---|---|
| id | String | PK (e.g. 'US', 'VN') |
| name | String | facility name |
| state_code | String | state/location code |

---

### `dim_order_identity` 🔄
> Engine: SharedReplacingMergeTree | Rows: ~14.6M
> **Cần FINAL khi query**
> Maps order_key ↔ order IDs ↔ seller/store info

| Column | Type | Ghi chú |
|---|---|---|
| order_key | UInt64 | surrogate key (PK) |
| vendor_ref | String | internal vendor reference |
| order_id | String | order ID string |
| seller_id | String | seller ID ⭐ |
| team_id | String | team ID ⭐ |
| store_id | String | store ID ⭐ |
| created_at | DateTime64(3,'UTC') | |
| updated_at | DateTime64(3,'UTC') | |

---

### `dim_order_status_mapping` 🔵
> Engine: SharedMergeTree | Rows: 16
> Order status mapping table (relational version of dict_order_status)

| Column | Type | Ghi chú |
|---|---|---|
| ord_status_custom | Int8 | order custom status code |
| business_status_code | Int8 | |
| business_status_name | String | human-readable ⭐ |
| status_group | String | status group ⭐ |
| ord_status | Int8 | raw status |
| is_terminal | UInt8 | |
| is_success | UInt8 | |
| is_failure | UInt8 | |

---

### `dim_payment_status_mapping` 🔵
> Engine: SharedMergeTree | Rows: 4
> Payment status mapping table

| Column | Type | Ghi chú |
|---|---|---|
| payment_status | Int8 | payment status code |
| business_status_name | String | |
| description | String | |
| is_terminal | UInt8 | |
| is_success | UInt8 | |
| is_failure | UInt8 | |

---

### `dim_seller` 🔄
> Engine: SharedReplacingMergeTree | Rows: 0 (empty)
> **Cần FINAL khi query**
> Seller dimension (currently empty — data not populated)

| Column | Type | Ghi chú |
|---|---|---|
| seller_key | UInt64 | surrogate key |
| seller_id | String | seller ID |
| email | String | |
| team_id | String | |
| system_code | String | |
| created_at | DateTime64(3,'UTC') | |
| updated_at | DateTime64(3,'UTC') | |

---

### `dim_time` 🔵
> Engine: SharedMergeTree | Rows: ~11.3K
> Full date dimension — thường dùng cho time intelligence

| Column | Type | Ghi chú |
|---|---|---|
| date_key | Int32 | YYYYMMDD integer key |
| full_date | Date | date value ⭐ |
| year | Int16 | |
| quarter | Int8 | 1-4 |
| month | Int8 | 1-12 |
| month_name | String | 'January'...'December' |
| week_of_year | Int8 | |
| day_of_month | Int8 | |
| day_of_week | Int8 | |
| day_name | String | 'Monday'...'Sunday' |
| is_weekend | Bool | |
| is_month_start | Bool | |
| is_month_end | Bool | |
| is_quarter_start | Bool | |
| is_quarter_end | Bool | |
| is_year_start | Bool | |
| is_year_end | Bool | |
| is_business_day | Bool | |
| is_holiday | Bool | |
| holiday_name | Nullable(String) | |
| holiday_type | Nullable(String) | |
| season | String | 'Spring'/'Summer'/'Fall'/'Winter' |
| is_last_business_day_of_month | Bool | |
| is_business_day_before_holiday | Bool | |
| is_business_day_after_holiday | Bool | |
| is_long_weekend | Bool | |

---

### `dim_time_bd` 🔵
> Engine: SharedMergeTree | Rows: ~11.3K
> Date dimension with business day sequence counter

| Column | Type | Ghi chú |
|---|---|---|
| full_date | Date | PK |
| is_business_day | UInt8 | 1 = business day |
| business_day_seq | UInt32 | sequential business day counter |

---

### `fact_order` 🔄
> Engine: SharedReplacingMergeTree | Rows: 0 (empty)
> **Cần FINAL khi query**
> Enriched order fact table — hiện rỗng, xem `fact_order_v1` hoặc `fact_order_v3`

| Column | Type | Ghi chú |
|---|---|---|
| ord_id | Int64 | PK = nh_order.ord_id |
| ord_name | Nullable(String) | |
| ord_total | Decimal(20,2) | |
| ord_subtotal | Decimal(20,2) | |
| ord_profit | Decimal(20,2) | |
| ord_promotion | Decimal(20,2) | |
| ord_discount | Decimal(20,2) | |
| ord_total_discount | Decimal(20,2) | |
| ord_type_discount | Int16 | |
| ord_fee_shipping | Decimal(20,2) | |
| ord_handle_fee | Decimal(20,2) | |
| ord_vat_total | Decimal(20,2) | |
| ord_is_vat | Nullable(Int16) | |
| ord_payment_status | Nullable(Int16) | |
| ord_payment_method | Int16 | |
| ord_payment_datetime | Int64 | unix payment time |
| ord_status | Int16 | |
| ord_deleted | Int16 | |
| ord_archived | Int16 | |
| is_approve | Int16 | |
| ord_tracking_status | Int16 | |
| ord_status_custom | Nullable(Int16) | custom status ⭐ |
| ord_priority | Int16 | |
| is_issue | Int16 | |
| ord_issue_status | Int16 | |
| cus_id | Int64 | seller FK |
| ord_cus_name | Nullable(String) | end customer name |
| ord_cus_email | String | end customer email |
| ord_cus_country | Int64 | |
| ord_cus_state | Int64 | |
| ord_cus_city | String | |
| ord_cus_province | String | |
| store_id | Int64 | |
| cam_id | Int64 | |
| platform_id | Int16 | |
| promotion_id | Int64 | |
| method_insert | Int16 | |
| method_insert_subtype | Int16 | |
| marketplace_id | Nullable(String) | |
| online_id | Nullable(String) | |
| online_name | Nullable(String) | |
| ord_shipping_method | Int16 | |
| ord_shipping_location | Nullable(Int16) | |
| ord_is_single | Int16 | |
| ord_is_split | Nullable(Int16) | |
| is_import | Int16 | |
| multiple_type | Int16 | |
| ord_print_provider | Int16 | |
| ord_time | DateTime | |
| ord_time_approve | Int64 | |
| total_line_items | Int32 | |
| total_quantity | Int64 | |
| total_line_revenue | Decimal(20,2) | |
| total_line_profit | Decimal(20,2) | |
| total_base_cost | Decimal(20,2) | |
| distinct_products | Int32 | |
| ord_date | Date | order date ⭐ |
| ord_month | String | 'YYYY-MM' |
| ord_year | UInt16 | |
| ord_day_of_week | UInt8 | |
| is_paid | UInt8 | 1 = paid ⭐ |
| is_cancelled | UInt8 | 1 = cancelled |
| margin_rate | Decimal(10,4) | profit / revenue |
| discount_rate | Decimal(10,4) | |
| _processed_at | DateTime64(3,'UTC') | |
| _action | LowCardinality(String) | |
| _timestamp | DateTime64(3,'UTC') | |

---

### `fact_order_event` 🔵
> Engine: SharedMergeTree | Rows: 0 (empty)
> Event sourcing / CDC-style order events — currently empty

| Column | Type | Ghi chú |
|---|---|---|
| event_time | DateTime64(3,'UTC') | event timestamp ⭐ |
| event_date | Date | partition key |
| order_id | UInt64 | FK → nh_order |
| cus_id | UInt32 | FK → nh_customer |
| user_id | UInt32 | FK → nh_user |
| entity_name | LowCardinality(String) | entity changed |
| entity_id | UInt64 | entity PK |
| item_id | UInt64 | FK → order_item |
| event_domain | LowCardinality(String) | domain |
| event_type | LowCardinality(String) | event type ⭐ |
| action | Enum8 | 'insert'/'update'/'delete' |
| amount | Decimal(18,4) | |
| currency | FixedString(3) | 'USD' |
| value_type | Enum8 | value type discriminator |
| value_str | String | string value |
| value_i64 | Int64 | integer value |
| value_f64 | Float64 | float value |
| value_dec | Decimal(18,4) | decimal value |
| value_bool | UInt8 | bool value |
| value_ts | DateTime64(3,'UTC') | timestamp value |
| tags | Map(String,String) | additional tags |
| payload_json | String | raw JSON payload |
| source_table | LowCardinality(String) | source table name |
| source_pk | UInt64 | source PK |
| cdc_ts | DateTime64(3,'UTC') | CDC timestamp |
| ingested_at | DateTime64(3,'UTC') | ingest time |
| event_id | UUID | unique event ID |

---

### `fact_order_fulfillment_performance` 🔄 ⭐
> Engine: SharedReplacingMergeTree | Rows: ~1.7M
> **Cần FINAL khi query**
> Fulfillment SLA tracking per order: paid → production → fulfilled → scanned → delivered

| Column | Type | Ghi chú |
|---|---|---|
| order_id | UInt64 | PK = nh_order.ord_id |
| ordx_fulfill_locate | LowCardinality(String) | fulfill location ⭐ |
| shipping_scope | LowCardinality(String) | shipping scope |
| shipping_class | LowCardinality(String) | shipping class (Standard/Express) ⭐ |
| country_code | LowCardinality(FixedString(2)) | destination country ⭐ |
| country_name | LowCardinality(String) | destination country name |
| fulfill_timezone | LowCardinality(String) | IANA timezone of facility |
| paid_at_utc | DateTime('UTC') | payment time UTC ⭐ |
| paid_at_local | DateTime | payment time local |
| production_at | Nullable(DateTime) | production start time |
| fulfilled_at | Nullable(DateTime) | fulfillment (ship) time ⭐ |
| first_scanned_at | Nullable(DateTime) | first carrier scan ⭐ |
| delivered_at | Nullable(DateTime) | delivery time ⭐ |
| is_shifted_production | UInt8 | 1 = production shifted to next business day |
| processing_hour | Nullable(Int16) | Production Time in hours (paid → fulfilled, production-adjusted) |
| first_scan_hour | Nullable(Int16) | Tracking Lag in hours (fulfilled → first scan) ⭐ |
| shipping_hour | Nullable(Int16) | Transit time in hours (fulfilled → delivered, calendar hours) |
| processing_day | Nullable(Float32) | **Production Time** (paid → fulfilled, production-adjusted days = processing_hour/24) ⭐ |
| first_scan_day | Nullable(Float32) | **Tracking Lag** (fulfilled → first scan, **business days**) ⭐ |
| shipping_day | Nullable(Float32) | Transit time (fulfilled → delivered, calendar days = shipping_hour/24) — **không phải paid→fulfilled** |
| updated_at | DateTime64(3,'UTC') | |

---

### `fact_order_fulfillment_performance_by_product` 🔄
> Engine: SharedReplacingMergeTree | Rows: ~1.5M
> **Cần FINAL khi query**
> Same as fact_order_fulfillment_performance but granularity = order + product_type

| Column | Type | Ghi chú |
|---|---|---|
| order_id | UInt64 | FK → nh_order |
| product_type | LowCardinality(String) | product type name ⭐ |
| ordx_fulfill_locate | LowCardinality(String) | |
| fulfill_timezone | LowCardinality(String) | |
| paid_at_utc | DateTime('UTC') | |
| paid_at_local | DateTime | |
| production_at | Nullable(DateTime) | |
| is_shifted_production | UInt8 | |
| fulfilled_at | Nullable(DateTime) | |
| first_scanned_at | Nullable(DateTime) | |
| delivered_at | Nullable(DateTime) | |
| processing_hour | Nullable(Int32) | |
| first_scan_hour | Nullable(Int32) | |
| shipping_hour | Nullable(Int32) | |
| processing_day | Nullable(Float32) | |
| first_scan_day | Nullable(Float32) | |
| shipping_day | Nullable(Float32) | |
| updated_at | DateTime64(3,'UTC') | |

---

### `fact_order_line` 🔄
> Engine: SharedReplacingMergeTree | Rows: 0 (empty)
> **Cần FINAL khi query**
> Order line items enriched — hiện rỗng, dùng `v__fact_order_line` thay thế

| Column | Type | Ghi chú |
|---|---|---|
| item_id | Int64 | PK = nh_order_item.ordi_id |
| order_id | Int64 | FK → nh_order |
| order_status | Int16 | |
| order_payment_status | Nullable(Int16) | |
| order_payment_method | Int16 | |
| seller_id | Int64 | seller (cus_id) |
| seller_email | String | |
| team_id | String | team ID ⭐ |
| store_id | String | store ID ⭐ |
| campaign_id | Int64 | FK → nh_campaigns |
| platform_id | Int16 | |
| payment_date_utc | DateTime | payment datetime UTC ⭐ |
| order_time | DateTime | order created time |
| order_date | Date | order date ⭐ |
| order_month | String | 'YYYY-MM' |
| order_type | String | order type label |
| fulfill_location | String | fulfill location ⭐ |
| fulfill_timezone | String | |
| tracking_number | Nullable(String) | |
| item_price | Decimal(20,2) | item selling price ⭐ |
| item_price_original | Decimal(20,2) | |
| price_extra | Decimal(20,2) | |
| item_quantity | Int64 | quantity ⭐ |
| units_per_item | Int16 | |
| item_fee_shipping | Decimal(20,2) | |
| item_base_cost | Nullable(Decimal(20,2)) | base cost |
| item_printing_cost | Nullable(Decimal(20,2)) | printing cost |
| item_vat_total | Decimal(20,2) | |
| item_handle_fee | Decimal(20,2) | |
| item_subtotal | Decimal(20,2) | |
| item_total | Decimal(20,2) | item total ⭐ |
| item_profit | Decimal(20,2) | item profit ⭐ |
| item_base_price | Decimal(20,2) | |
| item_time | DateTime | |
| item_status | Nullable(Int16) | item status |
| item_deleted | Nullable(Int16) | |
| item_quantity_printed | Nullable(Int16) | |
| item_quantity_error | Nullable(Int16) | |
| product_group | String | product group ⭐ |
| product_type | String | product type ⭐ |
| product | String | product name ⭐ |
| product_sku | String | SKU ⭐ |
| item_name | Nullable(String) | |
| product_campaign_id | Nullable(Int64) | |
| item_size | Nullable(Int64) | size ID |
| item_color | Nullable(Int64) | color ID |
| item_material_id | Nullable(Int64) | |
| item_print_type | Nullable(Int64) | |
| item_variant_id | Nullable(Int64) | |
| source_system | String | 'v1'/'v3' |
| _processed_at | DateTime64(3,'UTC') | |

---

### `fact_order_v1` 🔄 ⭐
> Engine: SharedReplacingMergeTree | Rows: ~14.5M
> **Cần FINAL khi query**
> Main active orders fact table (V1 system orders)

| Column | Type | Ghi chú |
|---|---|---|
| order_id_oms | Int64 | PK = nh_order.ord_id ⭐ |
| order_id_v3 | String | V3 system order ID |
| seller_id | String | seller ID ⭐ |
| team_id_v3 | String | team ID (V3 format) ⭐ |
| store_id_v1 | String | store ID (V1 format) ⭐ |
| created_at | DateTime64(3,'UTC') | order created time ⭐ |
| updated_at | DateTime64(3,'UTC') | |
| date_id | Int32 | FK → dim_time.date_key ⭐ |
| order_total | Decimal(20,2) | order total ⭐ |
| shipping_fee | Decimal(20,2) | shipping fee |

---

### `fact_order_v3` 🔄
> Engine: SharedReplacingMergeTree | Rows: ~80.5K
> **Cần FINAL khi query**
> V3 system orders fact table

| Column | Type | Ghi chú |
|---|---|---|
| order_id_oms | Int64 | PK = nh_order.ord_id |
| order_id_v3 | String | V3 order ID ⭐ |
| seller_id | String | |
| team_id_v3 | String | |
| store_id_v3 | String | store ID (V3 format) |
| created_at | DateTime64(3,'UTC') | |
| updated_at | DateTime64(3,'UTC') | |
| date_id | Int32 | FK → dim_time.date_key |
| order_total | Decimal(20,2) | |
| shipping_fee | Decimal(20,2) | |

---

### `fact_production_order_sla_tracker` 🔄 ⭐
> Engine: SharedReplacingMergeTree | Rows: ~1.3K
> **Cần FINAL khi query**
> Live production SLA tracker — active orders in production with deadline tracking

| Column | Type | Ghi chú |
|---|---|---|
| order_id | UInt64 | FK → nh_order |
| order_item_id | UInt64 | FK → nh_order_item |
| product_group | LowCardinality(String) | product group ⭐ |
| product_type | LowCardinality(String) | product type ⭐ |
| product | String | product name |
| product_sku | LowCardinality(String) | SKU |
| qty | UInt32 | quantity |
| units | UInt32 | total units |
| fulfill_location | LowCardinality(String) | fulfill location ⭐ |
| order_type | LowCardinality(String) | order type |
| payment_date | Date | payment date |
| payment_date_local | DateTime | payment date local |
| start_date | Date | production start date |
| production_start_at | DateTime | production start time |
| DD | Int32 | deadline day (business days since paid) |
| SLA | UInt8 | SLA target (business days) |
| priority_score | Int32 | calculated priority |
| priority_level | LowCardinality(String) | 'Critical'/'High'/'Medium'/'Low' ⭐ |
| days_to_deadline | Int32 | days remaining to SLA deadline ⭐ |
| deadline_status | String | 'On Track'/'At Risk'/'Overdue' ⭐ |
| sla_utilization_pct | Float64 | % of SLA used (0-100+) ⭐ |
| updated_at | DateTime | |

---

### `fact_production_order_sla_tracker_daily_snapshot` 🔵
> Engine: SharedMergeTree | Rows: ~228.6K
> Daily snapshots of production SLA tracker — historical record

Cùng columns với `fact_production_order_sla_tracker`, thêm:

| Column | Type | Ghi chú |
|---|---|---|
| order_id | UInt64 | |
| order_item_id | UInt64 | |
| product_group | LowCardinality(String) | |
| product_type | LowCardinality(String) | |
| product | String | |
| product_sku | LowCardinality(String) | |
| qty | UInt32 | |
| units | UInt32 | |
| fulfill_location | LowCardinality(String) | |
| order_type | LowCardinality(String) | |
| payment_date | Date | |
| payment_date_local | DateTime | |
| start_date | Date | |
| production_start_at | DateTime | |
| DD | Int32 | |
| SLA | UInt8 | |
| priority_score | Int32 | |
| priority_level | LowCardinality(String) | |
| days_to_deadline | Int32 | |
| deadline_status | String | |
| sla_utilization_pct | Float64 | |
| updated_at | DateTime | |
| snapshot_date | Date | date of snapshot ⭐ |
| snapshot_time | DateTime | time of snapshot |
| inserted_at | DateTime | |
| period_marker | Enum8 | 'intraday'/'eod' snapshot marker |

---

### Views

#### `v__fact_order_line` 🔵
> View trên `fact_order_line` — cùng columns nhưng types non-nullable
> Dùng thay vì fact_order_line trực tiếp

---

#### `v__g5000_dtg_campaign_2025` 🔵
> View — G5000 DTG campaign 2025 special data
> *(columns không document — xem MCP để explore)*

---

#### `v__order_production_sla_backlog_daily_clearance` 🔵
> View — Daily backlog clearance aggregated by:
> product_group, product_type, priority_level, fulfill_location, order_type

---

#### `v__usps_fulfilled_to_delivered_days` 🔵
> View — USPS delivery SLA: fulfilled → delivered (days)

---

#### `v__usps_fulfilled_to_first_scan_days` 🔵
> View — USPS first scan SLA: fulfilled → first scan (days)

---

#### `v__usps_paided_to_first_scan_days` 🔵
> View — USPS first scan from payment: paid → first scan (days)

---

#### `v__usps_shipping_day` 🔵
> View — USPS shipping days (business day count)

---

#### `v__usps_tracking_first_scan` 🔵
> View — First scan events per tracking number

---

#### `v_production_backlog_clearance_intraday` 🔵
> View — Intraday backlog clearance monitoring

---

## Internal Tables (không query trực tiếp)

| Table | Description |
|---|---|
| `mv__fact_order_fulfillment_performance` | MaterializedView → fact_order_fulfillment_performance |
| `mv__fact_order_fulfillment_performance_by_product` | MaterializedView → by_product variant |
| `mv__fact_production_order_sla_tracker` | MaterializedView → sla_tracker |
| `mv__g5000_dtg_campaign_2025` | MaterializedView → DTG campaign view |

---

## Patterns thường dùng

```sql
-- Lấy order với status label
SELECT
    o.ord_id,
    o.ord_time,
    dictGet('gea__silver.dict_order_status', 'business_status_name', toUInt64(o.ord_status_custom)) AS status_name,
    dictGet('gea__silver.dict_order_status', 'status_group', toUInt64(o.ord_status_custom)) AS status_group
FROM geadb__bronze.nh_order FINAL o
WHERE o.ord_deleted = 0

-- Join fact_order_v1 với dim_time
SELECT
    t.year,
    t.month,
    count() AS orders,
    sum(f.order_total) AS revenue
FROM gea__silver.fact_order_v1 FINAL f
JOIN gea__silver.dim_time t ON f.date_id = t.date_key
GROUP BY t.year, t.month
ORDER BY t.year, t.month

-- Fulfillment SLA average
SELECT
    ordx_fulfill_locate,
    country_code,
    avg(first_scan_day) AS avg_first_scan_days,
    avg(shipping_day) AS avg_shipping_days
FROM gea__silver.fact_order_fulfillment_performance FINAL
WHERE paid_at_utc >= '2025-01-01'
GROUP BY ordx_fulfill_locate, country_code
```
